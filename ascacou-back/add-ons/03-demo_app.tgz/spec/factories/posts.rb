FactoryBot.define do
  factory :post do
    title { "MyString" }
    upvotes { 1 }
  end
end
