FactoryBot.define do
  factory :comment do
    post { nil }
    description { "MyString" }
  end
end
