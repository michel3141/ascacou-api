class TopPostsController < ApplicationController
  def index
    base_scope = Post.where("upvotes > ?", 100)

    posts = PostResource.all(params, base_scope)

    render jsonapi: posts
  end
end
