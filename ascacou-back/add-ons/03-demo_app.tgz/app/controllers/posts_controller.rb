class PostsController < ApplicationController
  # With Graphiti::Rails::Responders included, these blocks collapse to
  # respond_with(posts). See https://graphiti.dev/getting-started/installation#responders
  def index
    posts = PostResource.all(params)

    respond_to do |format|
      format.jsonapi { render jsonapi: posts }
      format.json { render json: posts }
    end
  end

  def show
    post = PostResource.find(params)

    respond_to do |format|
      format.jsonapi { render jsonapi: post }
      format.json { render json: post }
    end
  end

  def create
    post = PostResource.build(params)

    if post.save
      render jsonapi: post, status: 201
    else
      render jsonapi_errors: post
    end
  end

  def update
    post = PostResource.find(params)

    if post.update
      render jsonapi: post
    else
      render jsonapi_errors: post
    end
  end

  def destroy
    post = PostResource.find(params)

    if post.destroy
      render jsonapi: { meta: {} }, status: 200
    else
      render jsonapi_errors: post
    end
  end
end
