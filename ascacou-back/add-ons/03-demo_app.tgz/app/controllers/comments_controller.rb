class CommentsController < ApplicationController
  # With Graphiti::Rails::Responders included, these blocks collapse to
  # respond_with(comments). See https://graphiti.dev/getting-started/installation#responders
  def index
    comments = CommentResource.all(params)

    respond_to do |format|
      format.jsonapi { render jsonapi: comments }
      format.json { render json: comments }
    end
  end

  def show
    comment = CommentResource.find(params)

    respond_to do |format|
      format.jsonapi { render jsonapi: comment }
      format.json { render json: comment }
    end
  end

  def create
    comment = CommentResource.build(params)

    if comment.save
      render jsonapi: comment, status: 201
    else
      render jsonapi_errors: comment
    end
  end

  def update
    comment = CommentResource.find(params)

    if comment.update
      render jsonapi: comment
    else
      render jsonapi_errors: comment
    end
  end

  def destroy
    comment = CommentResource.find(params)

    if comment.destroy
      render jsonapi: { meta: {} }, status: 200
    else
      render jsonapi_errors: comment
    end
  end
end
