class PostResource < ApplicationResource
  secondary_endpoint '/top_posts', [:index]
  has_many :comments
  attribute :title, :string
  attribute :upvotes, :integer
end
