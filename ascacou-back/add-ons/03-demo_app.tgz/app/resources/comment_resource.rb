class CommentResource < ApplicationResource
  belongs_to :post
  filter :post_id, :integer
  attribute :description, :string
end
