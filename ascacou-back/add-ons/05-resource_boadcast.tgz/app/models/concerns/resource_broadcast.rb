# Diffuse dans ActionCable les événements de cycle de vie d'un modèle
# lié à une ressource Graphiti (<Model>Resource).
module ResourceBroadcast
  extend ActiveSupport::Concern

  included do
    after_create_commit :on_create
    # not triggered on update_all
    after_update_commit :on_update
    after_destroy_commit :on_destroy
  end

  def notify(dest, event)
    ActionCable.server.broadcast dest, event
  end

  def notify_new()
    notify 'new-resource', new_event
  end

  def notify_update
    notify to_self, update_event
  end

  def notify_destroy
    notify to_self, destroy_event
  end

  protected

  def resource_endpoint
    "#{self.class.name.split('::').last}Resource".safe_constantize.endpoint.fetch(:path)
  rescue
    nil
  end

  def resource_type
    "#{self.class.name.split('::').last}Resource".safe_constantize.type
  rescue
    nil
  end

  def to_me
    ## called on User instance
    # for sending to the user session
    "connected_user##{id}"
  end

  def to_all
    # for sending to all users session
    "connected_users"
  end

  def to_self
    "resource-#{resource_type}-#{id}"
  end

  def new_event
    { type: resource_type, endpoint: resource_endpoint, id: id }
  end

  def update_event
    { event: "update" }
  end

  def destroy_event
    { event: "destroy" }
  end

  private

  def on_create
    return unless resource_type
    notify_new
  end

  def on_update
    return unless resource_type
    notify_update
  end

  def on_destroy
    return unless resource_type
    notify_destroy
  end
end
